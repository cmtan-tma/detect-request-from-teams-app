Content Security Policy Demo Starter Files
